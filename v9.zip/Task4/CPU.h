#ifndef CPU_H
#define CPU_H

#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Memory.h"

using namespace std;

class CPU {
    Register *reg = new Register();
    Memory *memory = new Memory();
    ALU *alu = new ALU();
    string IR;         // Instruction Register
    int PC = 0;
public:

    // Load an instruction into memory at the current PC and increment PC
    void loadNextInstruction(const string &instruction) {
        if (instruction.length() == 4) {
            // Split the 4-digit instruction into two parts
            string firstHalf = instruction.substr(0, 2);  // First two characters
            string secondHalf = instruction.substr(2, 2); // Last two characters

            // Store in two consecutive memory cells starting at PC
            memory->set(PC, firstHalf);        // Store the first half at PC
            memory->set(PC + 1, secondHalf);   // Store the second half at PC+1

            cout << "Instruction [" << instruction << "] Stored & PC = " << PC << "  PC = " << PC + 1 << "\n";
            memory->display_memory();  // Show the current state of memory

            // Update the Instruction Register
            IR = instruction;

        } else {
            cout << "Invalid instruction format. Please enter a 4 hex digit instruction.\n";
        }

        // Increment PC by 2 to point to the next instruction location
        PC += 2;
    }


    // Get the current instruction in the Instruction Register
    [[nodiscard]] string getInstructionRegister() const {
        return IR;
    }

    // Get the current value of the Program Counter
    [[nodiscard]] int getPC() const {
        return PC;
    }

    // Set the Program Counter to a specific value
    void setPC(const int &newPC) {
        PC = newPC;
    }
};

#endif // CPU_H
