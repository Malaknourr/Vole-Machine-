// CPU.h

#ifndef CPU_H
#define CPU_H

#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"


#include "Memory.h"

using namespace std;

class CPU {
    Register *reg = new Register();
    Memory *memory = new Memory();
    ALU *alu = new ALU();

    static int PC;            // Program Counter
    string IR;                // Instruction Register

public:
    CPU() : IR("") {}

    // Load an instruction into memory at the current PC and increment PC
    void loadNextInstruction(const string &instruction) {
        IR = instruction; // Load instruction to IR
        if (instruction.length() == 4) {
            // Split the 4-digit instruction into two parts
            string firstHalf = instruction.substr(0, 2); // First two characters
            string secondHalf = instruction.substr(2, 2); // Last two characters

            // Store in two consecutive memory cells starting at PC
            memory->set(PC, firstHalf);        // Store the first half at PC
            memory->set(PC + 1, secondHalf);   // Store the second half at PC+1

            cout << "Instruction " << instruction << " stored at PC = " << hex << uppercase << PC
                 << " and PC = " << PC+1 << "\n";
            cout << "IR = " << IR << "\n";

        } else {
            cout << "Invalid instruction format. Please enter a 4 hex digit instruction.\n";
        }
        PC += 2;    // Increment PC by 2 to point to the next instruction location
    }

    string getInstructionRegister() {
        return IR;
    }

    int &getPC() const {
        return PC;
    }

    void setPC(int pc) {
        PC = pc;
    }

    // Fetch the next instruction from memory and execute it
    void fetchAndExecuteNext() {
        string instruction = memory->get(PC) + memory->get(PC + 1);
        loadNextInstruction(instruction);
    }

};

#endif // CPU_H
