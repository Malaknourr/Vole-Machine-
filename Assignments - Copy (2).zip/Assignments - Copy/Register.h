// Register.h

#ifndef REGISTER_H
#define REGISTER_H
#include <vector>
#include <string>

using namespace std;

class Register {
    int size = 0;
    vector<string> Registers;

public:
    Register(int size) : size(size), Registers(size, "00") {}

    string getRegister(int index) const {
        return Registers[index];
    }

    void setRegister(int index ,  string reg) {
        if (index >= 0 && index < size - 1) { // Check for valid index
            Registers[index] = reg.substr(0, 2);
            Registers[index + 1] = reg.substr(2, 4);
        }
    }
};

#endif //REGISTER_H
