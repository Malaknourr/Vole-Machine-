// CPU.h

#ifndef CPU_H
#define CPU_H

#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Memory.h"

using namespace std;

class CPU {
    Register reg;
    Memory memory;
    ALU alu;
    //Control_Unit control;

    int PC = 0;                    // Program Counter
    string IR;                     // Instruction Register

public:
    CPU() : reg(16), memory(256) {}

    // Load next instruction from the input file into IR and increment PC
    void loadNextInstruction(ifstream& inputFile) { //==> IR must be separated from reading the file as the doctor need
        while(!inputFile.eof()) {
            getline(inputFile, IR);       // Load instruction to IR
            PC += 2;                      // Increment PC by 2
            cout << IR << endl ;
        }

        cout << "End of input file reached." << endl;
    }

    string runNextStep() {
        // Assuming IR holds a valid instruction in hex format
        if (!IR.empty()) {
            int address = stoi(ALU::HexToDec(IR.substr(2, 4))); // Convert hex address
            string value = memory.get(address);                 // Retrieve value from memory
            return value;
        } else {
            cout << "No instruction loaded in IR." << endl;
            return "";
        }
    }

};

#endif // CPU_H
