// Memory.h

#ifndef MEMORY_H
#define MEMORY_H

#include <vector>
#include <string>

using namespace std;

class Memory {
    vector<string> memory;
    int size;

public:
    Memory(int size) : size(size), memory(size, "00") {}

    void set(int index, const string &value) {
        if (index >= 0 && index < size) { // Check for valid index
            memory[index] = value;
        }
    }

    string get(int index) const {
        if (index >= 0 && index < size) { // Check for valid index
            return memory[index];
        }
        return ""; // Return an empty string if index is out of bounds
    }


};

#endif //MEMORY_H
