#include <iostream>
#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Memory.h"
#include "CPU.h"
using namespace std;
#include "Register.h"
#include "ALU.h"
#include<bits/stdc++.h>
int main() {
   //  Register obj(16);
   //  cout << obj.getRegister(0);
   //  cout << endl;
   //  obj.setRegister(1 , "4026");
   //  cout << obj.getRegister(1);
   //  cout << endl;
   //  cout << obj.getRegister(2);
   // obj.setRegister(3 , "3526");

   // cout <<  ALU ::AddBinary("FF" , "FF");

    // CPU CPU1;
    // CPU1.loadNextInstruction();

    // CPU cpu;  // Create CPU object
    // cpu.loadNextInstruction("instructions.txt"); // Open input file with instructions

    CPU cpu;                           // Create CPU object
    std::ifstream inputFile("zeft.txt");  // Open input file with instructions

    if (!inputFile.is_open()) {
        std::cerr << "Error: Could not open instructions file." << std::endl;
        return 1;
    }

    while (!inputFile.eof()) {
        cpu.loadNextInstruction(inputFile);    // Load the next instruction into IR
        std::string result = cpu.runNextStep();  // Execute the instruction in IR

        if (!result.empty()) {
            std::cout << "Executed instruction, result: " << result << std::endl;
        } else {
            std::cout << "No valid instruction to execute." << std::endl;
        }
    }

    inputFile.close();
    std::cout << "Program completed." << std::endl;
    return 0;
}