//
// Created by MALAK on 10/28/2024.
//

#ifndef CONTROL_UNIT_H
#define CONTROL_UNIT_H
#include<bits/stdc++.h>
#include"CPU.h"
using namespace std;


class Control_Unit {

public:
    Control_Unit() ;

};



#endif //CONTROL_UNIT_H
