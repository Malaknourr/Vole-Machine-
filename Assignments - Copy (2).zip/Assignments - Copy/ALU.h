//
// Created by MALAK on 10/28/2024.
//

#ifndef ALU_H
#define ALU_H
#include<bits/stdc++.h>
using namespace std;


class ALU {
public:

    static string HexToDec(const string& hexNum) {
        int decimalValue = stoi(hexNum, nullptr, 16); // Convert hex string to decimal integer
        return to_string(decimalValue);
    }


    static string BinToDec(const string& binNum) {
        bitset<32> bits(binNum); // Create a bitset from binary string
        int decimalValue = bits.to_ulong(); // Convert to unsigned long (integer)
        return to_string(decimalValue);
    }


    static string DecToHex(const string& num) {
        int decNum = stoi(num); // Convert decimal string to integer
        stringstream ss;
        ss << hex << uppercase << decNum; // Convert integer to hexadecimal string in uppercase
        return ss.str();
    }

    static string AddBinary(const string& Num1, const string& Num2) {
        string decNum1 = HexToDec(Num1); // Convert hexadecimal to decimal integer
        string decNum2 = HexToDec(Num2); // Convert hexadecimal to decimal integer

        int sum = stoi(decNum1) + stoi(decNum2); // Add the two decimal integers

        bitset<9> binarySum(sum); // Convert the sum to a 32-bit binary representation

        return binarySum.to_string(); // Return the result as a binary string
    }

    bool checkValid(string hexNum) {
        for(char& digit  : hexNum) {
            if (digit >= '0' && digit <= '9' || digit >= 'A' && digit <= 'F') {
                return true;
            }
            return false;
        }
    }

    //mentesa function => floating point numbers


};


#endif //ALU_H
