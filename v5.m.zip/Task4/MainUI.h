#ifndef MAINUI_H
#define MAINUI_H

#include "Register.h"
#include "ALU.h"
#include "Control_Unit.h"
#include "Memory.h"
#include "CPU.h"
#include <bits/stdc++.h>

using namespace std;

class MainUI {
    static Memory memory;
    static Register register_;
    static ALU alu;
    static Control_Unit control_unit;
    static CPU cpu;
    static int PC;

    // Static function to validate and load instructions from a file
    static vector<string> fileInstructions(ifstream &inputFile) {
        vector<string> instructions;
        string line;
        while (getline(inputFile, line)) {
            line = toUpperCase(line);
            if (isValidInstruction(line)) {
                instructions.push_back(line);
                if (line == "C000") {  // Stop at HALT command
                    break;
                }
            } else {
                cout << "Invalid instruction in file: " << line << " (must be 4 hex characters).\n";
            }
        }
        return instructions;
    }

public:
    static string toUpperCase(string &str) {
        ranges::transform(str, str.begin(), ::toupper);
        return str;
    }

    static void outputState() {
        string choice;
        cout << "What would you like to view? \n(A) memory\n(B) register\n(C) IR\n(D) PC\n";
        cin >> choice;
        choice = toUpperCase(choice);

        if (choice == "A") {
            memory.display_memory();
        } else if (choice == "B") {
            register_.display_registers();
        } else if (choice == "C") {
            cout << "Instruction Register (IR): " << cpu.getInstructionRegister() << "\n";
        } else if (choice == "D") {
            cout << "Program Counter (PC): " << cpu.getPC() << "\n";
        } else {
            cout << "Invalid choice, please try again.\n";
        }
    }

    static bool isValidChoice(char choice) {
        return choice == 'A' || choice == 'B' || choice == 'C' || choice == 'D';
    }

    static bool isValidInstruction(const string &instruction) {
        return instruction.length() == 4 && ranges::all_of(instruction, [](char c) {
            return isxdigit(c); // Check if each character is a hexadecimal digit
        });
    }

    static bool isValidFilename(const string &filename) {
        ifstream file(filename);
        bool exists = file.good();
        file.close();
        return exists;
    }

    static void executeInstructions(const vector<string> &instructions) {
        for (const auto &instruction : instructions) {
            cpu.loadNextInstruction(instruction);  // Load instruction into memory and update IR
            control_unit.opcode_checker(instruction, register_, memory, cpu.getPC()); // Execute with the updated PC
        }
    }

    static void menu() {
        cout << "Enter the memory start location (0 to 264): ";
        int location;
        cin >> location;
        memory.setStartLocation(location);
        cpu.setPC(location);  // Set initial PC

        while (true) {
            cout << "Enter your choice: " << endl;
            cout << "(A) Load Instructions from File\n" << "(B) Enter Instructions Manually\n" << "(C) Display State\n" << "(D) Execute Instructions\n" << "(E) Exit\n";
            char choice;
            cin >> choice;

            static vector<string> instructions;

            if (choice == 'A') {
                string filename;
                cout << "Enter the file name (e.g., instructions.txt): ";
                cin >> filename;
                if (isValidFilename(filename)) {
                    ifstream inputFile(filename);
                    instructions = fileInstructions(inputFile);
                } else {
                    cout << "File does not exist. Please try again.\n";
                }

            } else if (choice == 'B') {
                cout << "Enter instructions (4 hexadecimal characters each). Type 'C000' to end.\n";
                while (true) {
                    string inputIns;
                    cin >> inputIns;
                    inputIns = toUpperCase(inputIns);
                    if (isValidInstruction(inputIns)) {
                        instructions.push_back(inputIns);
                        if (inputIns == "C000") {  // HALT command
                            break;
                        }
                    } else {
                        cout << "Invalid instruction! Must be exactly 4 hexadecimal characters.\n";
                    }
                }

            } else if (choice == 'C') {
                outputState();

            } else if (choice == 'D') {
                if (!instructions.empty()) {
                    executeInstructions(instructions);  // Execute loaded instructions one by one
                    instructions.clear();  // Clear after execution if you want to re-load for new set
                } else {
                    cout << "No instructions loaded. Please load or enter instructions first.\n";
                }

            } else if (choice == 'E') {
                cout << "Program stopped.\n";
                break;

            } else {
                cout << "Invalid choice, please try again.\n";
            }
        }
    }
};

#endif // MAINUI_H
