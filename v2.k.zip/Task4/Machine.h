//
// Created by MALAK on 11/3/2024.
//
#include <iostream>
#include "Register.h"
#include "Control_Unit.cpp"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Memory.h"
//#include "CPU.h"
using namespace std;

#ifndef MACHINE_H
#define MACHINE_H



class Machine {
public:


};



#endif //MACHINE_H
