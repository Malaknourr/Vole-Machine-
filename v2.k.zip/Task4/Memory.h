// Memory.h

#ifndef MEMORY_H
#define MEMORY_H

#include <iostream>
#include <vector>
#include <string>
#include <iomanip> // For std::setw

using namespace std;

class Memory {
    vector<string> memory;
    int size;

public:
    Memory() : size(256), memory(256, "00") {}

    void set(int index, const string &value) {
        // Check for valid index
        if (index > 0 && index < size) { // Ensure index is greater than 0
            memory[index] = value;
        } else {
            cout << "Invalid index. Please enter a valid index greater than 0 and less than " << size << ".\n";
        }
    }

    string get(int index) const {
        if (index >= 0 && index < size) { // Check for valid index
            return memory[index];
        }
        return ""; // Return an empty string if index is out of bounds
    }

    void display_memory() {
        cout << endl << "Memory Display (16x16 Matrix)" << endl;

        // Print column headers
        cout << "   "; // Initial space for row header
        for (int col = 0; col < 16; col++) {
            cout << setw(2) << hex << uppercase << col << " "; // Column header (0-F)
        }
        cout << endl;

        // Print memory rows
        for (int row = 0; row < 16; row++) {
            cout << hex << uppercase << row << ": "; // Row header (0-F)

            for (int col = 0; col < 16; col++) {
                int index = row * 16 + col; // Calculate memory index
                if (index < size) {
                    cout << setw(2) << memory[index] << " "; // Memory content
                } else {
                    cout << "   "; // Empty space for out-of-bounds index
                }
            }
            cout << endl;
        }
    }
};

#endif //MEMORY_H
