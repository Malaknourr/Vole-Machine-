// CPU.h

#ifndef CPU_H
#define CPU_H

#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Control_Unit.cpp"

#include "Memory.h"

using namespace std;

class CPU {
    Register *reg = new Register();
    Memory *memory = new Memory();
    ALU *alu = new ALU();

    int PC ;                    // Program Counter
    string IR;                     // Instruction Register

public:
    CPU() : PC(0), IR("") {};

    void loadNextInstruction(string& line) {
            IR = line ;       // Load instruction to IR
            PC += 2;                      // Increment PC by 2
            cout << IR << endl ;
    }

    string runNextStep() {
        // Assuming IR holds a valid instruction in hex format
        if (!IR.empty()) {
            int address = stoi(ALU::HexToDec(IR.substr(2, 4))); // Convert hex address
            string value = memory -> get(address);                 // Retrieve value from memory
            return value;
        }

        cout << "No instruction loaded in IR." << endl;
        return "";

    }
    string getInstrucrionRegister() {
        return IR;
    }

    int getPC() {
        return PC;
    }

};

#endif // CPU_H
