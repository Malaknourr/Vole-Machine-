#include <iostream>
#include<bits/stdc++.h>
#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Memory.h"
#include "CPU.h"
#include "MainUI.h"
using namespace std;

// Define static members
Memory MainUI::memory;
Register MainUI::register_;
ALU MainUI::alu;
Control_Unit MainUI::control_unit;
int MainUI::PC = 0; // Optionally initialize PC to 0
CPU MainUI::cpu; // Assuming CPU has a default constructor

int main() {

    MainUI::menu();
}