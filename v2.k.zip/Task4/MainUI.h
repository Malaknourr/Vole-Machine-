//
// Created by MALAK on 11/3/2024.
//
#include "Register.h"
#include "ALU.h"
#include <bits/stdc++.h>
#include "Control_Unit.h"
#include "Memory.h"
#include "CPU.h"

using namespace std;

#ifndef MAINUI_H
#define MAINUI_H

class MainUI {
    static Memory memory;
    static Register register_;
    static ALU alu;
    static Control_Unit control_unit;
    static int PC;
    static CPU cpu;

public:
    static string toUpperCase(string &str) {
        transform(str.begin(), str.end(), str.begin(), ::toupper);
        return str;
    }

    static void fileInstructions(ifstream& inputFile) {
        string line;
        while (getline(inputFile, line)) {
            // Validate each instruction before processing
            if (isValidInstruction(line)) {
                Control_Unit::opcode_checker(line, register_, memory, PC);
            } else {
                cout << "Invalid instruction in file: " << line << " (must be 4 hex characters).\n";
            }
        }
    }

    // Static function to display the state of various CPU components
    static void outputState(CPU& cpu, Memory& mem, const Register& reg) {
        string choice;
        cout << "What would you like to view? \n(A) memory\n(B) register\n(C) IR\n(D) PC\n";
        cin >> choice;

        // Convert choice to uppercase to ensure case-insensitivity
        choice = toUpperCase(choice);

        if (choice == "A") {
            mem.display_memory();
        } else if (choice == "B") {
            reg.display_registers();
        } else if (choice == "C") {
            cout << "Instruction Register (IR): " << cpu.getInstrucrionRegister() << "\n";
        } else if (choice == "D") {
            cout << "Program Counter (PC): " << cpu.getPC() << "\n";
        } else {
            cout << "Invalid choice, please try again.\n";
        }
    }
    static bool isValidChoice(char choice) {
        return choice == 'A' || choice == 'B' || choice == 'C' || choice == 'D';
    }

    static bool isValidInstruction(const string& instruction) {
        return instruction.length() == 4 && all_of(instruction.begin(), instruction.end(), [](char c) {
            return isxdigit(c); // Check if each character is a hexadecimal digit
        });
    }

    static bool isValidFilename(const string& filename) {
        ifstream file(filename);
        bool exists = file.good();
        file.close();
        return exists;
    }

    static void menu() {
        while (true) {
            cout << "Enter the choice: " << endl;
            cout << "(A) Enter Instructions' file\n" << "(B) Run Instructions\n" << "(C) Display State\n" << "(D) Exit\n";
            char choice;
            cin >> choice;

            if (isValidChoice(choice)) {
                if (choice == 'A') {
                    string filename;
                    cout << "Enter File's name.txt: ";
                    cin >> filename;

                    if (isValidFilename(filename)) {
                        ifstream inputFile(filename);
                        fileInstructions(inputFile);
                    } else {
                        cout << "File does not exist. Please try again.\n";
                    }

                } else if (choice == 'B') {
                    while (true) {
                        string instruction;
                        cout << endl << "Please enter the instruction (4 hex digits): ";
                        cin >> instruction;
                        string instruction1 = toUpperCase(instruction);

                        if (isValidInstruction(instruction1)) {
                            Control_Unit::opcode_checker(instruction1, register_, memory, PC);
                        } else {
                            cout << "Invalid instruction! It must contain exactly 4 hexadecimal characters.\n";
                        }
                    }
                } else if (choice == 'C') {
                    outputState(cpu, memory, register_);
                } else if (choice == 'D') {
                    cout << "Program Stopped\n";
                    break;
                }
            } else {
                cout << "Invalid choice, please try again.\n";
            }
        }
    }
};

#endif //MAINUI_H
